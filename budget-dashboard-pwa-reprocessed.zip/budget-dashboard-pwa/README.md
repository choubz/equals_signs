# Budget Dashboard — PWA (Reprocessed)
Deploy these files to an HTTPS host (Netlify, Vercel, GitHub Pages, Cloudflare Pages). On Android Chrome: open the URL → menu → **Install app**.
- Offline after first load (service worker caches app + Chart.js).
- Start URL: `index.html` with scope `./` for subfolder hosting.
